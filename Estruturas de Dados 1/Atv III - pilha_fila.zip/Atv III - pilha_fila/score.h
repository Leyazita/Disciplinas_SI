#ifndef SCORE_H
#define SCORE_H

#include "cliente.h"
#include "rota.h"

float calcular_escore(int entregas_efetuadas, int entregas_nao_efetuadas);

#endif
