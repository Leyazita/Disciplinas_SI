import requests


def testar_funcoes():
    payloads = [

        {"funcao": "fatorial", "numero": 4}, 
        {"funcao": "arranjo", "n": 6, "r": 2},
        {"funcao": "combinacao", "n": 4, "r": 2},
        {"funcao": "permutacao", "numero": 8}]


    for _ in range(3):
        for payload in payloads:
            response = requests.post('https://redes2-95qyjbbf.b4a.run/calcular', json=payload)
            print(response.text)


if __name__ == '__main__':
    testar_funcoes()
